<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Retrieve People From Faction</title>
</head>
<body>
<body style="background-color:black;"> </body>
<h2><font color="white"><p align="center">Retrieve People From Faction</p></font></h2>
<form action="RetrievePeopleByFaction.php" method="POST">
<font color="white"><p align="center">Faction </font><input type="text" name="faction" /></p><br>
<p align="center"><input type="submit" value="Go" /></p>
</form>

</body>
</html>