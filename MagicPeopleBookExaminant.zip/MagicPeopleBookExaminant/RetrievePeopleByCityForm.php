<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Retrieve People From City</title>
</head>
<body>
<body style="background-color:black;"> </body>
<h2><font color="white"><p align="center">Retrieve People From City</p></font></h2>
<form action="RetrievePeopleByCity.php" method="POST">
<font color="white"><p align="center">City </font><input type="text" name="city" /></p><br>
<p align="center"><input type="submit" value="Go" /></p>
</form>

</body>
</html>