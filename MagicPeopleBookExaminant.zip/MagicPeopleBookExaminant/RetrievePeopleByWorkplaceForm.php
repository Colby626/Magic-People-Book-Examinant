<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Retrieve People From Workplace</title>
</head>
<body>
<body style="background-color:black;"> </body>
<h2><font color="white"><p align="center">Retrieve People From Workplace</p></font></h2>
<form action="RetrievePeopleByWorkplace.php" method="POST">
<font color="white"><p align="center">Workplace </font><input type="text" name="workplace" /></p><br>
<p align="center"><input type="submit" value="Go" /></p>
</form>

</body>
</html>