<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Retrieve Person Information</title>
</head>
<body>
<body style="background-color:black;"> </body>
<h2><font color="white"><p align="center">Retrieve Person Information</p></font></h2>
<form action="RetrievePersonInfo.php" method="POST">
<font color="white"><p align="center">Name </font><input type="text" name="name" /></p><br>
<p align="center"><input type="submit" value="Go" /></p>
</form>

</body>
</html>