<?php
require_once('./mysqli_connect.php');

if (!$dbc) {
    die("Connection failed: " . mysqli_connect_error());
}
$mysqli = new mysqli("localhost","root","csc","magic_people_book");

$personName=$_POST["name"];
$profession=$_POST["profession"];
$skill=$_POST["skill"];
$workplace=$_POST["workplace"];
$city=$_POST["city"];
$faction=$_POST["faction"];

$sql="INSERT INTO people VALUES ('$personName', '$profession', '$skill', '$workplace', '$city', '$faction')";

if (mysqli_query($dbc, $sql)) {
    echo "<html>";
    echo "<head>";
    echo "<style>";
    echo "body { background-color: black; color: white; }";
    echo "</style>";
    echo "</head>";
    echo "<body>";
    echo "Record added successfully";
    echo "</body>";
    echo "</html>";
}
else {
    echo "<html>";
    echo "<head>";
    echo "<style>";
    echo "body { background-color: black; color: white; }";
    echo "</style>";
    echo "</head>";
    echo "<body>";
    echo "Error updateing record: " . mysql_error($conn);
    echo "</body>";
    echo "</html>";
}

mysqli_close($dbc);
?>