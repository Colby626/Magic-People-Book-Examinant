<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Delete Person</title>
</head>
<body>
<body style="background-color:black;"> </body>
<h2><font color="white"><p align="center">Delete Person</p></font></h2>
<form action="DeleteMagicPerson.php" method="POST">
<font color="white"><p align="center">Name </font><input type="text" name="name" /></p><br>
<p align="center"><input type="submit" value="Go" /></p>
</form>

</body>
</html>