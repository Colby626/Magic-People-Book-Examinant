<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Retrieve People From Profession And City</title>
</head>
<body>
<body style="background-color:black;"> </body>
<h2><font color="white"><p align="center">Retrieve People From Profession And City</p></font></h2>
<form action="RetrieveByProfessionAndCity.php" method="POST">
<font color="white"><p align="center">Profession</font><input type="text" name="profession" /> </p><br>
<font color="white"><p align="center">City </font><input type="text" name="city" /></p><br>
<p align="center"><input type="submit" value="Go" /></p>
</form>

</body>
</html>