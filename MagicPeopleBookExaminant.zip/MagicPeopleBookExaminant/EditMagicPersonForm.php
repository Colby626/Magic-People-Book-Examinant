<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Edit Person</title>
</head>
<body>
<body style="background-color:black;"> </body>
<h2><font color="white"><p align="center">Edit Person</p></font></h2>
<form action="EditMagicPerson.php" method="POST">
<font color="white"><p align="center">Name</font> <input type="text" name="name" /></p><br>
<font color="white"><p align="center">Profession</font><input type="text" name="profession" /></p> <br>
<font color="white"><p align="center">Skill</font> <input type="number" name="skill" /></p><br>
<font color="white"><p align="center">Workplace</font> <input type="text" name="workplace" /></p><br>
<font color="white"><p align="center">City</font> <input type="text" name="city" /></p><br>
<font color="white"><p align="center">Faction</font> <input type="text" name="faction" /></p><br>
<p align="center"><input type="submit" value="Go" /></p>
</form>

</body>
</html>