<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Delete Person</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
	<h2>Delete Person</h2>
	<form action="DeleteMagicPerson.php" method="POST">
		<label for="name">Name</label>
		<input type="text" name="name" id="name" />
		<input type="submit" value="Go" />
	</form>
</body>
</html>
