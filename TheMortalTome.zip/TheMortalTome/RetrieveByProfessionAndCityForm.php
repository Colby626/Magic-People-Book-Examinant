<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Retrieve People From Profession And City</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
	<h2>Retrieve People From Profession And City</h2>
	<form action="RetrieveByProfessionAndCity.php" method="POST">
		<label for="profession">Profession</label>
		<input type="text" name="profession" id="profession" />
		<label for="city">City</label>
		<input type="text" name="city" id="city" />
		<input type="submit" value="Go" />
	</form>
</body>
</html>
