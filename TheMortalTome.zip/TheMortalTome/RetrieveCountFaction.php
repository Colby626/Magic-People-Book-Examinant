<?php
require_once('./mysqli_connect.php');

if (!$dbc) {
    die("Connection failed: " . mysqli_connect_error());
}
$mysqli = new mysqli("localhost","root","","the-mortal-tome");

$sql="SELECT Faction, COUNT(Name) as count FROM `people` GROUP BY Faction ORDER BY COUNT(Name) DESC";

$result = mysqli_query($dbc, $sql);
echo "<html>";
echo "<head>";
echo "<link rel='stylesheet' href='styles.css'>";
echo "</head>";
echo "<body>";
echo "<table border='1'>
<tr>
<th>Faction</th>
<th>Number of People</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
	echo "<tr>";
	echo "<td>" . $row['Faction'] . "</td>";
	echo "<td>" . $row['count'] . "</td>";
	echo "</tr>";
}
echo "</table>";
echo "</body>";
echo "</html>";

mysqli_close($dbc);
?>