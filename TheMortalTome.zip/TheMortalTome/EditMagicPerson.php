<?php
require_once('./mysqli_connect.php');

if (!$dbc) {
    die("Connection failed: " . mysqli_connect_error());
}
$mysqli = new mysqli("localhost","root","","the-mortal-tome");

$personName = $_POST["name"];
$profession = $_POST["profession"];
$skill = $_POST["skill"];
$workplace = $_POST["workplace"];
$city = $_POST["city"];
$faction = $_POST["faction"];

$update_fields = array();
if (!empty($profession)) {
    $update_fields[] = "Profession = '$profession'";
}
if (!empty($skill)) {
    $update_fields[] = "Skill = '$skill'";
}
if (!empty($workplace)) {
    $update_fields[] = "Workplace = '$workplace'";
}
if (!empty($city)) {
    $update_fields[] = "City = '$city'";
}
if (!empty($faction)) {
    $update_fields[] = "Faction = '$faction'";
}
if (!empty($update_fields)) {
    $update_query = "UPDATE people SET " . implode(', ', $update_fields) . " WHERE Name = '$personName'";
}

if ($mysqli->query($update_query) === true) {
    echo "<html>";
    echo "<head>";
    echo "<link rel='stylesheet' href='styles.css'>";
    echo "</head>";
    echo "<body>";
    echo "<div style='color: white;'>Person Edited</div>";
    echo "</body>";
    echo "</html>";
} else {
    echo "<html>";
    echo "<head>";
    echo "<link rel='stylesheet' href='styles.css'>";
    echo "</head>";
    echo "<body>";
    echo "Error: " . $mysqli->error;
    echo "</body>";
    echo "</html>";
}

mysqli_close($dbc);
?>