<?php
require_once('./mysqli_connect.php');

if (!$dbc) {
    die("Connection failed: " . mysqli_connect_error());
}
$mysqli = new mysqli("localhost","root","csc","the-mortal-tome");

$personName=$_POST["name"];

$sql="DELETE FROM people WHERE Name = '$personName'";

if ($mysqli->query($sql) === true) {
    echo "<html>";
    echo "<head>";
    echo "<link rel='stylesheet' href='styles.css'>";
    echo "</head>";
    echo "<body>";
    echo "<div style='color: white;'>Person Deleted</div>";
    echo "</body>";
    echo "</html>";
} else {
    echo "<html>";
    echo "<head>";
    echo "<link rel='stylesheet' href='styles.css'>";
    echo "</head>";
    echo "<body>";
    echo "Error: " . $mysqli->error;
    echo "</body>";
    echo "</html>";
}

mysqli_close($dbc);
?>