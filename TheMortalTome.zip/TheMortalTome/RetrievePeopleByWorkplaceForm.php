<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Retrieve People From Workplace</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
	<h2>Retrieve People From Workplace</h2>
	<form action="RetrievePeopleByWorkplace.php" method="POST">
		<label for="workplace">Workplace</label>
		<input type="text" name="workplace" id="workplace" />
		<input type="submit" value="Go" />
	</form>
</body>
</html>
