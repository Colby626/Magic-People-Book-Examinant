<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Retrieve People From Profession</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
	<h2>Retrieve People From Profession</h2>
	<form action="RetrievePeopleByProfession.php" method="POST">
		<label for="profession">Profession</label>
		<input type="text" name="profession" id="profession" />
		<input type="submit" value="Go" />
	</form>
</body>
</html>
