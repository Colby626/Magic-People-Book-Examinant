<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Add Person</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
	<h2>Add Person</h2>
	<form action="AddMagicPerson.php" method="POST">
		<label for="name">Name</label>
		<input type="text" name="name" id="name" />
		<label for="profession">Profession</label>
		<input type="text" name="profession" id="profession" />
		<label for="skill">Skill</label>
		<input type="number" name="skill" id="skill" />
		<label for="workplace">Workplace</label>
		<input type="text" name="workplace" id="workplace" />
		<label for="city">City</label>
		<input type="text" name="city" id="city" />
		<label for="faction">Faction</label>
		<input type="text" name="faction" id="faction" />
		<input type="submit" value="Go" />
	</form>
</body>
</html>
