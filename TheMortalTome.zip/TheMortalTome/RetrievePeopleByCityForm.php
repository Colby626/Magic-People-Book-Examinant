<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Retrieve People From City</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
	<h2>Retrieve People From City</h2>
	<form action="RetrievePeopleByCity.php" method="POST">
		<label for="city">City</label>
		<input type="text" name="city" id="city" />
		<input type="submit" value="Go" />
	</form>
</body>
</html>
