<?php
require_once('./mysqli_connect.php');
s
$repo_path = '/path/to/repository';
$file_name = 'VersionNumber.txt';
$versionNumber = 0;
// Use the Git command-line tool to read the file contents
$file_contents = shell_exec("cd $repo_path && git show HEAD:$file_name");

// Output the contents of the file (might need to cast to a number)
if ($file_contents > versionNumber)
{
    //notify user of new version available 
    echo "<html>";
    echo "<head>";
    echo "<link rel='stylesheet' href='styles.css'>";
    echo "</head>";
    echo "<body>";
    echo "<div style='color: white;'>New version available! Go to https://colbykade626.itch.io/mortal-tome to get the new version</div>";
    echo "</body>";
    echo "</html>";
};
?>