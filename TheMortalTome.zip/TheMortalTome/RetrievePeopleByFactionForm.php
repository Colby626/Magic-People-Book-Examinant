<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Retrieve People From Faction</title>
	<link rel="stylesheet" href="styles.css">
</head>
<body>
	<h2>Retrieve People From Faction</h2>
	<form action="RetrievePeopleByFaction.php" method="POST">
		<label for="faction">Faction</label>
		<input type="text" name="faction" id="faction" />
		<input type="submit" value="Go" />
	</form>
</body>
</html>
