<?php
require_once('./mysqli_connect.php');

$mysqli = new mysqli("localhost","root","csc","the-mortal-tome");

if ($mysqli->connect_errno) {
    die("Connection failed: " . $mysqli->connect_error);
}

$personName = $_POST["name"];
$profession = $_POST["profession"];
$skill = $_POST["skill"];
$workplace = $_POST["workplace"];
$city = $_POST["city"];
$faction = $_POST["faction"];

$sql = "INSERT INTO people VALUES ('$personName', '$profession', '$skill', '$workplace', '$city', '$faction')";

if ($mysqli->query($sql) === true) {
    echo "<html>";
    echo "<head>";
    echo "<link rel='stylesheet' href='styles.css'>";
    echo "</head>";
    echo "<body>";
    echo "<div style='color: white;'>Person Added</div>";
    echo "</body>";
    echo "</html>";
} else {
    echo "<html>";
    echo "<head>";
    echo "<link rel='stylesheet' href='styles.css'>";
    echo "</head>";
    echo "<body>";
    echo "Error: " . $mysqli->error;
    echo "</body>";
    echo "</html>";
}

$mysqli->close();
?>
